package empmanagementapplication;

import java.util.Scanner;

public class Main 
{
	EmployeeService service=new EmployeeService();
	//static boolean Ordering=true;
	public static void menu()
	{
		System.out.println("------- Welcome to Employee Management System--------");
		System.out.println("Enter 1 to Add Element");
		System.out.println("Enter 2 to View Element");
		System.out.println("Enter 3 to Update Element");
		System.out.println("Enter 4 to Delete Element");
		System.out.println("Enter 5 to View all Elements");
		System.out.println("Enter 6 to Exit");
	}
	public static void main(String[] args) 
	{
		Scanner scan=new Scanner(System.in);
		EmployeeService service=new EmployeeService();
		do {
			menu();
			System.out.println("Enter your choice");
			int choice=scan.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Add Element");
				service.createEmp();
				break;
			case 2:
				System.out.println("View Element");
				service.viewEmp();
				break;
			case 3:
				System.out.println("Update Element");
				service.updateEmp();
				break;
			case 4:
				System.out.println("Delete Element");
				service.deleteEmp();
				break;
			case 5:
				System.out.println("View all Element");
				service.viewAllEmployee();
				break;
			case 6:
				System.out.println("thank you for using this Application");
				System.exit(0);
			default :
			{
				System.out.println("please enter valid information");
				break;
			}
			}	
			
		}while(true);
		
	}
}
