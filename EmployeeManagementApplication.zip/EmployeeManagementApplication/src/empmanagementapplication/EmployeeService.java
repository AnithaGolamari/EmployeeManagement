package empmanagementapplication;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class EmployeeService 
{
	HashSet<Employee> empset=new HashSet<Employee>();
	
	Employee emp1=new Employee(101,"Anu",20,"IT","Developer",35000.00,"female");
	Employee emp2=new Employee(102,"Deepu",17,"Science","Doctor",50000.00,"female");
	Employee emp3=new Employee(103,"siva",19,"IT","Software Enginner",30000.00,"male");
	
	Scanner scan=new Scanner(System.in);
	boolean found=false;
	int id;
	String name;
	int age;
	String designation;
	String department;
	double salary;
	String gender;
	
	public EmployeeService()
	{
		empset.add(emp1);
		empset.add(emp2);
		empset.add(emp3);
	}
	
	// view all Employee
	public void viewAllEmployee()
	{
		boolean found=false;
		for(Employee emp:empset)
		{
			System.out.println(emp);
			found=true;
		}
		if(!found)
		{
			System.out.println("not found");
		}
	}
	
	// view Employee
	public void viewEmp()
	{
		boolean found=false;
		System.out.println("enter ID");
		id=scan.nextInt();
		for(Employee emp:empset)
		{
			if(emp.getId()==id)
			{
				System.out.println(emp);
				found=true;
			}
		}
		if(!found)
		{
			System.out.println("not found employee");
		}
	}
		// update Employee
		public void updateEmp()
		{
			boolean found=false;
			System.out.println("enter ID");
			id=scan.nextInt();
			for(Employee emp:empset)
			{
				if(emp.getId()==id)
				{
					System.out.println("enter 1 to update name");
					System.out.println("enter 2 to update Id");
					System.out.println("enter 3 to update age");
					System.out.println("enter 4 to update designation");
					System.out.println("enter 5 to update department");
					System.out.println("enter 6 to update salary");
					System.out.println("enter 7 to update gender");
					System.out.println("enter your choice");
					int choice=scan.nextInt();
					switch(choice)
					{
					case 1:
					{
						System.out.println("enter New Name :");
						name=scan.next();
						emp.setName(name);
						break;
					}
					case 2:
					{
						System.out.println("enter new ID");
						id=scan.nextInt();
						emp.setId(id);
						break;
					}
					case 3:
					{
						System.out.println("enter New Age");
						age=scan.nextInt();
						emp.setAge(age);
						break;
					}
					case 4:
					{
						System.out.println("enter new Designation");
						designation=scan.next();
						emp.setDesignation(designation);
						break;
					}
					case 5:
					{
						System.out.println("enter new Department");
						department=scan.next();
						emp.setDepartment(department);
						break;
					}
					case 6:
					{
						System.out.println("enter new salary");
						salary=scan.nextDouble();
						emp.setSalary(salary);
						break;
					}
					case 7:
					{
						System.out.println("enter new gender");
						gender=scan.next();
						emp.setGender(gender);
						break;
					}
					default :
					{
						System.out.println("enter valid choice");
					}
				}
					System.out.println(emp);
					found=true;
				}
			}
			if(!found)
			{
				System.out.println("not found employee");
			}
			}
		public void deleteEmp()
		{
			boolean found=false;
			System.out.println("enter ID");
			id=scan.nextInt();
			Employee empdelete=null;
			for(Employee emp:empset)
			{
				if(emp.getId()==id)
				{
					empdelete=emp;
					found=true;
				}
			}
			if(!found)
			{
				System.out.println("employee is not present..");
			}
			else
			{
				empset.remove(empdelete);
				System.out.println("deletion successful");
			}
		}
		public void createEmp()
		{
			System.out.println("enter Id");
			id=scan.nextInt();
			System.out.println("enter Name");
			name=scan.next();
			System.out.println("enter age");
			age=scan.nextInt();
			System.out.println("enter disignation");
			designation=scan.next();
			System.out.println("enter department");
			department=scan.next();
			System.out.println("enter salary");
			salary=scan.nextDouble();
			System.out.println("enter gender");
			gender=scan.next();
			Employee emp=new Employee(id,name,age,designation,department,salary,gender);
			empset.add(emp);
			System.out.println(emp);
			System.out.println("Employee added successfully...");
		}
}
